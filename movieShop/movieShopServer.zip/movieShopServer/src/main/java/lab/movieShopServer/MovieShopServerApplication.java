package lab.movieShopServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieShopServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieShopServerApplication.class, args);
	}

}
